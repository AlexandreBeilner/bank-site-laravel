<?php

namespace App\Application\Billet\Exceptions;

class BilletNotFoundException extends \Exception
{

}
