<?php

namespace App\Application\Billet\UseCases\ShowBillet;

use App\Application\Shared\DTOs\IdDTO;

final class ShowBilletRequest extends IdDTO
{
}
