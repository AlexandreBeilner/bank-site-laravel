<?php

namespace App\Application\Billet\UseCases\DestroyBillet;

use App\Application\Shared\DTOs\IdDTO;

final class DestroyBilletRequest extends IdDTO
{
}
