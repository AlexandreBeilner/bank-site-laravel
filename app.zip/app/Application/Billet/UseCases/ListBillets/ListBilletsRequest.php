<?php

namespace App\Application\Billet\UseCases\ListBillets;

use App\Application\Shared\DTOs\ListDTO;

final class ListBilletsRequest extends ListDTO
{
}
