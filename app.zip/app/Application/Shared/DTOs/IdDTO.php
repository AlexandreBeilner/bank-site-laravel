<?php

namespace App\Application\Shared\DTOs;

class IdDTO
{
    public function __construct(public int $id)
    {
    }
}
