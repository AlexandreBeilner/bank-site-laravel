<?php

namespace App\Application\Customer\UseCases\DestroyCustomer;

use App\Application\Shared\DTOs\IdDTO;

final class DestroyCustomerRequest extends IdDTO
{
}
