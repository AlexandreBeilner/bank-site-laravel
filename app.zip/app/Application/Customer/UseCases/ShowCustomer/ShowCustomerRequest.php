<?php

namespace App\Application\Customer\UseCases\ShowCustomer;

use App\Application\Shared\DTOs\IdDTO;

final class ShowCustomerRequest extends IdDTO
{
}
