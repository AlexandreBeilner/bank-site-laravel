<?php

namespace App\Application\Customer\UseCases\ListCustomers;

use App\Application\Shared\DTOs\ListDTO;

final class ListCustomersRequest extends ListDTO
{
}
