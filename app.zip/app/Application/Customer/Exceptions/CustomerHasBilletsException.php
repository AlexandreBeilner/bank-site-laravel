<?php

namespace App\Application\Customer\Exceptions;

class CustomerHasBilletsException extends \Exception
{

}
