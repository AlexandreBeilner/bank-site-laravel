<?php

namespace App\Application\Customer\Exceptions;

class CustomerNotFoundException extends \Exception
{

}
