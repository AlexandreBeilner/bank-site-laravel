<?php

namespace App\Application\Bank\UseCases\ListBanks;

use App\Application\Shared\DTOs\ListDTO;

final class ListBanksRequest extends ListDTO
{
}
