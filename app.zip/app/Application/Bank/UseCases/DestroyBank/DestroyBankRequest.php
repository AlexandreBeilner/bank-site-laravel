<?php

namespace App\Application\Bank\UseCases\DestroyBank;

use App\Application\Shared\DTOs\IdDTO;

final class DestroyBankRequest extends IdDTO
{
}
