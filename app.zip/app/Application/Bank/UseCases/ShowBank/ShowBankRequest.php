<?php

namespace App\Application\Bank\UseCases\ShowBank;

use App\Application\Shared\DTOs\IdDTO;

final class ShowBankRequest extends IdDTO
{
}
