<?php

namespace App\Application\Bank\Exceptions;

class BankHasBilletsException extends \Exception
{

}
