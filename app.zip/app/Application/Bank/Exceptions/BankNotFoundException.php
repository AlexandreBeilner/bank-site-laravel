<?php

namespace App\Application\Bank\Exceptions;

class BankNotFoundException extends \Exception
{

}
